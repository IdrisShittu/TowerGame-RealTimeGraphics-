#include "PointLight.h"



PointLight::PointLight()
{
}


PointLight::~PointLight()
{
}
